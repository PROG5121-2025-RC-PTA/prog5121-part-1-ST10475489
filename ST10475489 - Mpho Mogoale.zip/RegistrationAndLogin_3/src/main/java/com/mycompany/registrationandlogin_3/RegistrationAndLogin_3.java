/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin_3;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;

public class RegistrationAndLogin_3 {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    
    // User data
    private String username;
    private String firstName;
    private String lastName;
    private String password;
    private String phoneNumber;
    private boolean isRegistered = false;
    
    // GUI components
    private JTextField firstNameField, lastNameField, usernameField;
    private JPasswordField passwordField;
    private JTextField phoneField;
    private JLabel messageLabel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new RegistrationAndLogin_3().createAndShowGUI();
        });
    }

    private void createAndShowGUI() {
        frame = new JFrame("Registration and Login System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        
        createWelcomePanel();
        createRegistrationPanel();
        createLoginPanel();
        
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private void createWelcomePanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        JLabel titleLabel = new JLabel("Welcome to Registration and Login System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(e -> cardLayout.show(mainPanel, "register"));
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(registerBtn, gbc);
        
        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> cardLayout.show(mainPanel, "login"));
        gbc.gridx = 1;
        panel.add(loginBtn, gbc);
        
        mainPanel.add(panel, "welcome");
    }

    private void createRegistrationPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Title
        JLabel titleLabel = new JLabel("Registration Form");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        // Form fields
        gbc.gridwidth = 1;
        gbc.gridy++;
        panel.add(new JLabel("First Name:"), gbc);
        gbc.gridx = 1;
        firstNameField = new JTextField(20);
        panel.add(firstNameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Last Name:"), gbc);
        gbc.gridx = 1;
        lastNameField = new JTextField(20);
        panel.add(lastNameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Username (with _, ≤5 chars):"), gbc);
        gbc.gridx = 1;
        usernameField = new JTextField(20);
        panel.add(usernameField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password (8+ chars, 1 cap, 1 num, 1 special):"), gbc);
        gbc.gridx = 1;
        passwordField = new JPasswordField(20);
        panel.add(passwordField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Phone (+country code):"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(20);
        panel.add(phoneField, gbc);
        
        // Message label
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        messageLabel = new JLabel(" ");
        messageLabel.setForeground(Color.RED);
        panel.add(messageLabel, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "welcome"));
        buttonPanel.add(backBtn);
        
        JButton registerBtn = new JButton("Register");
        registerBtn.addActionListener(e -> registerUser());
        buttonPanel.add(registerBtn);
        
        gbc.gridy++;
        panel.add(buttonPanel, gbc);
        
        mainPanel.add(panel, "register");
    }

    private void createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Title
        JLabel titleLabel = new JLabel("Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);
        
        // Form fields
        gbc.gridwidth = 1;
        gbc.gridy++;
        panel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        JTextField loginUserField = new JTextField(20);
        panel.add(loginUserField, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        JPasswordField loginPassField = new JPasswordField(20);
        panel.add(loginPassField, gbc);
        
        // Message label
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        JLabel loginMessageLabel = new JLabel(" ");
        loginMessageLabel.setForeground(Color.RED);
        panel.add(loginMessageLabel, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> cardLayout.show(mainPanel, "welcome"));
        buttonPanel.add(backBtn);
        
        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> {
            boolean success = loginUser(loginUserField.getText(), new String(loginPassField.getPassword()));
            if (success) {
                loginMessageLabel.setForeground(Color.GREEN);
                loginMessageLabel.setText(String.format("Welcome %s %s, it is great to see you again.", firstName, lastName));
            } else {
                loginMessageLabel.setForeground(Color.RED);
                loginMessageLabel.setText("Username or password incorrect, please try again.");
            }
        });
        buttonPanel.add(loginBtn);
        
        gbc.gridy++;
        panel.add(buttonPanel, gbc);
        
        mainPanel.add(panel, "login");
    }

    private void registerUser() {
        firstName = firstNameField.getText();
        lastName = lastNameField.getText();
        username = usernameField.getText();
        password = new String(passwordField.getPassword());
        phoneNumber = phoneField.getText();
        
        StringBuilder errors = new StringBuilder();
        
        if (!checkUserName(username)) {
            errors.append("Username is not correctly formatted.\n");
        }
        if (!checkPasswordComplexity(password)) {
            errors.append("Password does not meet requirements.\n");
        }
        if (!checkCellPhoneNumber(phoneNumber)) {
            errors.append("Cell phone number incorrectly formatted.\n");
        }
        
        if (errors.length() > 0) {
            messageLabel.setText("<html>" + errors.toString().replace("\n", "<br>") + "</html>");
        } else {
            isRegistered = true;
            messageLabel.setForeground(Color.GREEN);
            messageLabel.setText("Registration successful!");
            clearRegistrationForm();
            cardLayout.show(mainPanel, "welcome");
        }
    }

    private boolean loginUser(String inputUsername, String inputPassword) {
        if (!isRegistered) {
            JOptionPane.showMessageDialog(frame, "Please register first.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return inputUsername.equals(username) && inputPassword.equals(password);
    }

    private boolean checkUserName(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }

    private boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }
            
            if (hasCapital && hasNumber && hasSpecialChar) {
                break;
            }
        }
        
        return hasCapital && hasNumber && hasSpecialChar;
    }

    private boolean checkCellPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) return false;
        String regex = "^\\+[1-9]\\d{0,2}\\d{7,15}$";
        return Pattern.matches(regex, phoneNumber);
    }

    private void clearRegistrationForm() {
        firstNameField.setText("");
        lastNameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        phoneField.setText("");
    }
}



